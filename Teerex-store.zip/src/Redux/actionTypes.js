export const  GET_PRODUCTS ="GET_PRODUCTS";
export const  ADD_CART ="ADD_CART";
export const REMOVE_CART ="REMOVE_CART"
export const SEARCH_PRODUCTS ="SEARCH_PRODUCTS"
export const SET_FILTER = "SET_FILTER"

